# Imperium roster (names from the official ID guide). No stat profiles: ORBAT 4.01 Beta was not accessible.
R = [
 ("Flagship", [
  ("Asgard Rotor Tethership","airship"),("Elector Battleship (Primär)","battleship"),("Elector Battleship (Sekundär)","battleship"),
  ("Falkenstein Battlecarrier (Primär)","carrier"),("Falkenstein Battlecarrier (Sekundär)","carrier"),
  ("Ice Maiden Dreadnought Super-Carrier","carrier"),("Kaiser Heavy Battleship","battleship"),("König Generator Ship","battleship"),
  ("Maximilian Aerial Linebreaker","skyfortress"),("SMS Skjalden","battleship"),("Ragnarök Heavy Reaver","battleship"),
  ("SMS Brandenburg","battleship"),("Stark Imperium Skyfortress","skyfortress"),("Tempelhof Fleet Carrier","carrier"),
  ("Valhalla Fast Dreadnought","battleship"),("Zeppelin Aerial Dreadnought","skyfortress")]),
 ("Line", [("Blucher Cruiser","cruiser"),("Odin Reaver","cruiser"),("Jotunn Heavy Raider","cruiser"),
  ("Thor Assault Raider","cruiser"),("Nuremberg Heavy Airship","airship"),("Volsung Cruiser","cruiser")]),
 ("Patrol", [("Arminius Frigate","frigate"),("Gungnir Raider","destroyer"),("Jaeger Aerial Destroyer","airship"),
  ("Nachtsturm Flak Frigate","frigate"),("Sigimer Destroyer","destroyer"),("Baldr Raider","destroyer"),
  ("Hoth Corvette","frigate"),("Munich Aerial Destroyer","airship"),("Reiter Flak Cruiser","cruiser"),("Toten Heavy Destroyer","destroyer")]),
 ("Support", [("Angrboda Midget Sub-Carrier","submarine"),("Augustus Bombardment Cruiser","cruiser"),("Ferdinand Advanced Cruiser","cruiser"),
  ("Kriegsturm Assault Airship","airship"),("Offshore Heavy Platform","stronghold"),("Offshore Defence Platform","stronghold"),
  ("Schaumburg Escort Cruiser","cruiser")]),
 ("Scout", [("Einherjar Vitruvian Colossus","colossus"),("Fenrir Submarine","submarine"),("Hochmeister Vitruvian Colossus","colossus"),
  ("Loki Shadow Raider","destroyer"),("Malus Flak Destroyer","destroyer"),("Metzger Vitruvian Colossus","colossus"),("Valkyrie Hunt Rotor","airship")]),
 ("Logistical", [("Europa Grand Conveyor","transport"),("Gefjon Merchantman","transport"),("Hermes Supply Freighter","transport"),
  ("Heidelberg Logistics Battlecruiser (Primär)","cruiser"),("Heidelberg Logistics Battlecruiser (Sekundär)","cruiser"),
  ("Offshore Supply Platform","stronghold"),("Titan Mass Conveyor","transport")]),
]
UNITS = [dict(name=n, cat=c, cls=k) for c, lst in R for n, k in lst]
SRS = [("Blitzen Bombers","srs"),("Messer Interceptors","srs"),("Vali Midget Subs","srs"),("Landing Party","escort"),("Escort","escort")]
WEAPONS = ["Rüdiger Heavy Voltaic Gun Battery","Autokanone Stromschlag Rocket Battery","Light Voltaic Gun Battery",
 "Erderschütterer Rocket Battery","Sturmklaue Vierling Autokanone","Sturmbringer Vierling Flak Array",
 "Heavy Sturmklaue Luft Speerschleuders","Bertha Heavy Bombard","Gustav Twin Bombard","Uber Volt Vierling"]
