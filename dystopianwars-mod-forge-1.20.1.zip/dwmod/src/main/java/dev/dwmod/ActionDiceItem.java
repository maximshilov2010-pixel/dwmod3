package dev.dwmod;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class ActionDiceItem extends Item {
    private static final String[] FACE_KEYS = {"blank", "std_counter", "heavy_counter", "std_strike", "heavy_strike", "exploding"};

    public ActionDiceItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int dice = stack.getCount();
            DiceLogic.Result r = DiceLogic.roll(dice, bound -> level.random.nextInt(bound));
            MutableComponent msg = Component.translatable("msg." + DystopianWarsMod.MODID + ".dice.header",
                    player.getDisplayName(), dice).withStyle(ChatFormatting.GOLD);
            for (int i = 0; i < 6; i++) {
                if (r.faces[i] > 0) {
                    msg.append(Component.literal("\n  " + r.faces[i] + "x ").withStyle(ChatFormatting.GRAY));
                    msg.append(Component.translatable("face." + DystopianWarsMod.MODID + "." + FACE_KEYS[i])
                            .withStyle(ChatFormatting.WHITE));
                }
            }
            msg.append(Component.literal("\n"));
            msg.append(Component.translatable("msg." + DystopianWarsMod.MODID + ".dice.total",
                    r.hits(), r.counters(), r.extra).withStyle(ChatFormatting.YELLOW));
            broadcast(level, player, msg);
            player.getCooldowns().addCooldown(this, 10);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    static void broadcast(Level level, Player roller, Component msg) {
        for (Player p : level.players()) {
            if (p.distanceToSqr(roller) <= 64.0D * 64.0D && p instanceof ServerPlayer sp) {
                sp.sendSystemMessage(msg);
            }
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip." + DystopianWarsMod.MODID + ".action_dice.1").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip." + DystopianWarsMod.MODID + ".action_dice.2").withStyle(ChatFormatting.DARK_GRAY));
    }
}
