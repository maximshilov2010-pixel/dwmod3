package dev.dwmod;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Builds vanilla written books from text files in assets/dystopianwars/guides/ru/. */
public final class GuideBooks {
    private GuideBooks() {}

    private static final Map<String, Guide> CACHE = new HashMap<>();

    private record Guide(String title, List<String> pagesJson) {}

    public static ItemStack create(String guideId) {
        Guide guide = CACHE.computeIfAbsent(guideId, GuideBooks::load);
        ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = stack.getOrCreateTag();
        tag.putString("title", guide.title());
        tag.putString("author", "Dystopian Wars Mod");
        tag.putInt("generation", 0);
        ListTag pages = new ListTag();
        for (String json : guide.pagesJson()) {
            pages.add(StringTag.valueOf(json));
        }
        tag.put("pages", pages);
        return stack;
    }

    private static Guide load(String guideId) {
        String raw;
        String path = "/assets/" + DystopianWarsMod.MODID + "/guides/ru/" + guideId + ".txt";
        try (InputStream in = GuideBooks.class.getResourceAsStream(path)) {
            if (in == null) {
                raw = "@title " + guideId + "\nGuide file not found: " + path;
            } else {
                raw = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            raw = "@title " + guideId + "\nCannot read guide: " + e.getMessage();
        }
        raw = raw.replace("\r", "");
        String title = guideId;
        if (raw.startsWith("@title ")) {
            int nl = raw.indexOf('\n');
            title = (nl < 0 ? raw.substring(7) : raw.substring(7, nl)).trim();
            raw = nl < 0 ? "" : raw.substring(nl + 1);
        }
        if (title.length() > 32) {
            title = title.substring(0, 32);
        }
        List<String> json = new ArrayList<>();
        for (String page : BookPaginator.paginate(raw)) {
            MutableComponent comp = Component.empty();
            for (String line : page.split("\n", -1)) {
                if (line.startsWith("# ")) {
                    comp.append(Component.literal(line.substring(2) + "\n").withStyle(ChatFormatting.BOLD, ChatFormatting.DARK_RED));
                } else {
                    comp.append(Component.literal(line + "\n").withStyle(ChatFormatting.BLACK));
                }
            }
            json.add(Component.Serializer.toJson(comp));
        }
        if (json.isEmpty()) {
            json.add(Component.Serializer.toJson(Component.literal("(empty)")));
        }
        return new Guide(title, json);
    }
}
