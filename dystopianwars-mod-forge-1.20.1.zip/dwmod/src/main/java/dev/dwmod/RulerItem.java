package dev.dwmod;

import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** 1 block = 1 inch. Measures horizontal distance between block centres; height is ignored (Rule Book 4.00). */
public class RulerItem extends Item {
    private static final String[] BANDS = {"close", "standard", "extreme", "edge10", "edge30"};

    public RulerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        Level level = context.getLevel();
        if (player == null) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos();
        ItemStack stack = context.getItemInHand();
        CompoundTag tag = stack.getOrCreateTag();
        if (!tag.contains("ax") || player.isShiftKeyDown()) {
            tag.putInt("ax", pos.getX());
            tag.putInt("az", pos.getZ());
            player.displayClientMessage(Component.translatable("msg." + DystopianWarsMod.MODID + ".ruler.set",
                    pos.getX(), pos.getZ()).withStyle(ChatFormatting.AQUA), true);
        } else {
            double dx = pos.getX() - tag.getInt("ax");
            double dz = pos.getZ() - tag.getInt("az");
            double dist = Math.sqrt(dx * dx + dz * dz);
            String shown = String.format(Locale.ROOT, "%.1f", dist);
            Component band = Component.translatable("band." + DystopianWarsMod.MODID + "." + BANDS[DiceLogic.rangeBand(dist)]);
            player.displayClientMessage(Component.translatable("msg." + DystopianWarsMod.MODID + ".ruler.result",
                    shown, band).withStyle(ChatFormatting.GREEN), true);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                CompoundTag tag = stack.getOrCreateTag();
                tag.remove("ax");
                tag.remove("az");
                player.displayClientMessage(Component.translatable("msg." + DystopianWarsMod.MODID + ".ruler.reset"), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable("tooltip." + DystopianWarsMod.MODID + ".ruler." + i).withStyle(ChatFormatting.GRAY));
        }
    }
}
